<?php include("common.php"); ?>
<?php include("checkadminlogin.php"); 
get_right(array(1, 2));

	$ID = "";
// FOR PRODUCT 
	$NewOldProduct = 0;
	$aa = 1; $bb = 9; for($a=0; $a<BARCODE_LENGTH; $a++) { $aa = $aa*10; $bb = $bb*10; }
	$a=rand($aa,$bb);

	$BarCode = substr($a, 0, BARCODE_LENGTH);
	$OldBarCode = "";
	$CategoryID="";
	$ProductID = 0;
	$ProductName = "";
	$ShortDescription = "";
	$Description = "";
	$WholePrice = 0;
	$RetailPrice = 0;
	$CurrentStock = 0;
	$Stock = 0;
	$PImage="";
	$DateAdded = "";
	$DateModified = "";

// FOR SUPPLIER
	$NewOldSupplier = 0;
	$SupplierName = "";
	$SupplierID=0;
	$SImage = "user.jpg";
	$NIC = "";
	$Number = "";
	$Address = "";
	$Remarks = "";
	$Email = "";

// FOR Amount
	$Paid = 0;
	$Discount = 0;
	$TotalAmount = 0;
	$Note = '';

if(isset($_POST['addpurchase']) && $_POST['addpurchase']=='Save')
{
	$msg = "";
	foreach($_POST as $key => $value)
	{
		$$key=$value;
	}

	if(CAPTCHA_VERIFICATION == 1) { if(!isset($_POST["captcha"]) || $_POST["captcha"]=="" || $_SESSION["code"]!=$_POST["captcha"]) $msg = '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Incorrect Captcha Code</div>'; }
	else if(!isset($_POST["Stock"]) || $Stock <= 0) $msg = '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Please Enter Valid New Stock</div>';
	else if(!isset($_POST["WholePrice"]) || $WholePrice <= 0) $msg = '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Please Enter Valid Whole Sale Price</div>';
	else if((isset($_POST["ProductID"]) && ($_POST["ProductID"] == "" || $_POST["ProductID"] == "0"))) $msg = '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Please Select a Product</div>';
	else if((isset($_POST["SupplierName"]) && $_POST["SupplierName"] == "") && (isset($_POST["SupplierID"]) && ($_POST["SupplierID"] == "" || $_POST["SupplierID"] == "0"))) $msg = '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Please Select a Supplier</div>';
	else if($NewOldProduct == "1" && (checkavailability('products', 'BarCode', $BarCode) > 0 || $BarCode == '' || strlen($BarCode) != BARCODE_LENGTH)) { $msg = '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Please Enter a Unique Bar Code for your product</div>'; }
	else if($NewOldProduct == "0" && $OldBarCode != $BarCode && (checkavailability('products', 'BarCode', $BarCode) > 0 || $BarCode == '')) { $msg = '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>Please Enter a Unique Bar Code!</div>'; }

	else if(isset($_FILES["PFile"]) && $_FILES["PFile"]['name'] != "")
	{
		$filenamearray2=explode(".", $_FILES["PFile"]['name']);
		$ext2=End($filenamearray2);
	
		if(!in_array($ext2, $_IMAGE_ALLOWED_TYPES))
		{
			$msg='<div class="alert alert-danger alert-dismissable">
			<i class="fa fa-ban"></i>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<b>Only '.implode(", ", $_IMAGE_ALLOWED_TYPES) . ' Images can be uploaded. as product image.</b>
			</div>';
		}			
		else if($_FILES["PFile"]['size'] > (MAX_IMAGE_SIZE*1024))
		{
			$msg='<div class="alert alert-danger alert-dismissable">
			<i class="fa fa-ban"></i>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<b>Image size must be ' . MAX_IMAGE_SIZE . ' KB or less.</b>
			</div>';
		}
	}
	else if(isset($_FILES["SFile"]) && $_FILES["SFile"]['name'] != "")
	{
		$filenamearray2=explode(".", $_FILES["SFile"]['name']);
		$ext2=End($filenamearray2);
	
		if(!in_array($ext2, $_IMAGE_ALLOWED_TYPES))
		{
			$msg='<div class="alert alert-danger alert-dismissable">
			<i class="fa fa-ban"></i>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<b>Only '.implode(", ", $_IMAGE_ALLOWED_TYPES) . ' Images can be uploaded in supplier image.</b>
			</div>';
		}			
		else if($_FILES["SFile"]['size'] > (MAX_IMAGE_SIZE*1024))
		{
			$msg='<div class="alert alert-danger alert-dismissable">
			<i class="fa fa-ban"></i>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			<b>Image size must be ' . MAX_IMAGE_SIZE . ' KB or less.</b>
			</div>';
		}
	}

	if($msg == "")
	{
		$query1 = ($NewOldProduct == "1" ? 'INSERT INTO ' : 'UPDATE ').'products SET DateModified=NOW(),
				'.($NewOldProduct == "1" ? 'Name ="'.$ProductName.'", ' : '').'
				BarCode = "'.dbinput($BarCode).'",
				CategoryID = "'.dbinput($CategoryID).'",
				ShortDescription = "'.dbinput($ShortDescription).'",
				Description = "'.dbinput($Description).'",
				WholePrice = "'.dbinput($WholePrice).'",
				RetailPrice = "'.dbinput($RetailPrice).'",
				PerformedBy = "'.(int)$_SESSION["ID"].'",
				Stock = Stock+'.dbinput($Stock).'
				'.($NewOldProduct == "0" ? ' WHERE ID='.$ProductID : ' ');
		$a = mysql_query($query1) or die (mysql_error());
		if($NewOldProduct == 1)
		{
			$PID = mysql_insert_id();
			if(isset($_FILES["PFile"]) && $_FILES["PFile"]['name'] != "")
			{
				$tempName2 = $_FILES["PFile"]['tmp_name'];
				$realName2 = $PID.".".$ext2;
				$StoreImage = $realName2; 
				$target2 = DIR_PRODUCT_IMAGES . $realName2;

				if(is_file(DIR_PRODUCT_IMAGES . $StoreImage))
					unlink(DIR_PRODUCT_IMAGES . $StoreImage);
			
				ini_set('memory_limit', '-1');
				

				$moved2=move_uploaded_file($tempName2, $target2);
			
				if($moved2)
				{
					$query2="UPDATE products SET Image='" . dbinput($realName2) . "' WHERE  ID=" . (int)$PID;
					mysql_query($query2) or die(mysql_error());
					$_SESSION["msg"]='<div class="alert alert-danger alert-dismissable">
						<i class="fa fa-ban"></i>
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
						Only one query executed. Supplier info not inserted.
						</div>';
				}
			}
		}
		else
		{
			$PID = $ProductID;
		}
		$_SESSION["msg"]='<div class="alert alert-danger alert-dismissable">
				<i class="fa fa-ban"></i>
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				Only one query executed. Supplier info not updated.
				</div>';
	}
	
	if($msg == "")
	{
		$query2 = ($NewOldSupplier == "1" ? 'INSERT INTO ' : 'UPDATE ').' users SET DateModified=NOW(),
				'.($NewOldSupplier == "1" ? 'Name ="'.($SupplierName == '' ? 'Anonymous' : $SupplierName).'", ' : '').'
				NIC = "'.dbinput($NIC).'",
				Number = "'.dbinput($Number).'",
				Address = "'.dbinput($Address).'",
				Email = "'.dbinput($Email).'",
				PerformedBy = "'.(int)$_SESSION["ID"].'",
				Remarks = "'.dbinput($Remarks).'"
				'.($NewOldSupplier == "0" ? ' WHERE ID='.$SupplierID : ' ');
//				echo $query2; exit();
		mysql_query($query2) or die (mysql_error());
		if($NewOldSupplier == 1)
		{
			$SID = mysql_insert_id();
			if(isset($_FILES["SFile"]) && $_FILES["SFile"]['name'] != "")
			{
				$tempName2 = $_FILES["SFile"]['tmp_name'];
				$realName2 = $SID.".".$ext2;
				$StoreImage = $realName2; 
				$target2 = DIR_USER_IMAGES . $realName2;

				if(is_file(DIR_USER_IMAGES . $StoreImage))
					unlink(DIR_USER_IMAGES . $StoreImage);
			
				ini_set('memory_limit', '-1');
				
				$moved2=move_uploaded_file($tempName2, $target2);
			
				if($moved2)
				{
					$query2="UPDATE users SET Image='" . dbinput($realName2) . "' WHERE  ID=" . (int)$SID;
					mysql_query($query2) or die(mysql_error());
					$_SESSION["msg"]='<div class="alert alert-danger alert-dismissable">
						<i class="fa fa-ban"></i>
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
						Only two queries executed. Purchase record not added.
						</div>';
				}
			}
		}
		else
		{
			$SID = $SupplierID;
		}
		$_SESSION["msg"]='<div class="alert alert-danger alert-dismissable">
				<i class="fa fa-ban"></i>
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				Only two queries executed. Purchase record not added.
				</div>';
	}
	
	if($msg == "")
	{
		$query3 = "INSERT INTO purchases SET DateAdded = NOW(),
				ProductID='".(int)$PID."',
				SupplierID='".(int)$SID."',
				Price='".(float)$WholePrice."',
				Quantity='".(float)$Stock."',
				Discount='".(float)$Discount."',
				Total='".(float)($TotalAmount-$Discount)."',
				Paid='".(float)$Paid."',
				Unpaid='".(float)($TotalAmount - $Paid - $Discount)."',
				PerformedBy = '".(int)$_SESSION["ID"]."',
				Note='".dbinput($Note)."'
				";
				
		mysql_query($query3) or die(mysql_error());
		$InvoiceID = mysql_insert_id();
		mysql_query("UPDATE purchases SET RefNum='".generate_refno($InvoiceID)."' WHERE ID=".$InvoiceID);
		
		$_SESSION["msg"]='<div class="alert alert-success alert-dismissable">
			<i class="fa fa-ban"></i>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			Purchase has been added!
			</div>';
		redirect("purchaseinvoice.php?ID=".$InvoiceID);
	}
		$_SESSION["msg"] = $msg;
}

?>
<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo SITE_TITLE; ?>- Add Purchase</title>
    <link rel="icon" href="<?php echo DIR_LOGO_IMAGE.SITE_LOGO; ?>" type="image/x-icon">
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
    <!-- Select2 -->
    <link rel="stylesheet" href="plugins/select2/select2.min.css">
    <!-- AdminLTE Skins. We have chosen the skin-blue for this starter
          page. However, you can choose any other skin. Make sure you
          apply the skin class to the body tag so the changes take effect.
    -->
    <link rel="stylesheet" href="dist/css/skins/skin-blue.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <!--
  BODY TAG OPTIONS:
  =================
  Apply one or more of the following classes to get the
  desired effect
  |---------------------------------------------------------|
  | SKINS         | skin-blue                               |
  |               | skin-black                              |
  |               | skin-purple                             |
  |               | skin-yellow                             |
  |               | skin-red                                |
  |               | skin-green                              |
  |---------------------------------------------------------|
  |LAYOUT OPTIONS | fixed                                   |
  |               | layout-boxed                            |
  |               | layout-top-nav                          |
  |               | sidebar-collapse                        |
  |               | sidebar-mini                            |
  |---------------------------------------------------------|
  -->
  <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

      <!-- Main Header -->
      <?php include("header.php"); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <?php include("leftsidebar.php"); ?>
      

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Add Purchase
            <small></small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="purchases.php"><i class="fa fa-cart-arrow-down"></i> Purchases</a></li>
            <li class="active">Add Purchase</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-md-12">
              <!-- /.box -->
				<form id="frmPages" action="<?php echo $self; ?>" class="form-horizontal" method="post" enctype="multipart/form-data">
              <div class="box ">
                <div class="box-header">
                      <div class="btn-group-right">
                       <button style="float:right;margin-right:15px;" type="button" onClick="location.href='addpurchase.php'" class="btn btn-group-vertical btn-info">Reset</button>
                       <button style="float:right;margin-right:15px;" type="button" class="btn btn-group-vertical btn-danger" onClick="location.href='purchases.php'" >Back</button>
                       <input style="float:right;margin-right:15px;" type="submit" name="addpurchase" class="btn btn-group-vertical btn-success" value="Save"></button>
                      </div>
				</div>
			  </div>
<?php if(isset($_SESSION["msg"]) && $_SESSION["msg"] != "")  { echo $_SESSION["msg"]; $_SESSION["msg"]=""; } ?>
              <div class="col-md-6">
              <div class="box box-default">
				<div class="box-header with-border">
				  <h3 class="box-title">Product Information</h3>
				  <div class="box-tools pull-right">
					<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				  </div>
				</div>
                <div class="box-body">
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input"></label>
						<div class="col-md-8">
							<input type="checkbox" value="1" id="NewOldProduct" <?php echo ($NewOldProduct == "1") ? 'checked=""' : '' ;?> name="NewOldProduct"><label> New Product</label>
						</div>
					</div>
                    <div class="form-group" id="ProductName">
						<label class="col-md-3 control-label" for="example-text-input">Product Name</label>
						<div class="col-md-8">
							<input type="text" class="form-control" value="<?php echo $ProductName;?>" placeholder="Enter Product Name" name="ProductName">
						</div>
					</div>
                    <div class="form-group" id="ProductID">
					<label class="col-md-3 control-label" for="example-text-input">Product</label>
						<div class="col-md-8">
							<select class="form-control select2" data-placeholder="Select The Product" name="ProductID" style="width: 100%;">
								<option value="0"></option>
								<?php
									$r = mysql_query("SELECT ID, Name FROM products ") or die(mysql_error());
									$n = mysql_num_rows($r);
									if($n == 0)
									{
										echo '<option value="0">No Product Added</option>';
									}
									else
									{
										while($Rs = mysql_fetch_assoc($r)) { ?>
										<option value="<?php echo $Rs['ID']; ?>" <?php if($ProductID==$Rs['ID']) { echo 'Selected=""'; } ?>><?php echo $Rs['Name']; ?></option>
										<?php }
									}
							?>
							</select>
							<div id="PImage"></div>
						</div>
					</div>
					<div class="form-group" id="PFile">
						<label class="col-md-3 control-label" for="example-text-input">Image</label>
						<div class="col-md-8">
							<input type="file" name="PFile">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Bar Code</label>
						<div class="col-md-8">
							<input type="text" class="form-control" value="<?php echo $BarCode; ?>" placeholder="" name="BarCode">
							<p><span>*</span>Bar Code must be unique</p>
							<input type="hidden" name="OldBarCode" value="<?php echo $OldBarCode; ?>">
						</div>
					</div>
                    <div class="form-group">
					<label class="col-md-3 control-label" for="example-text-input">Category</label>
						<div class="col-md-8">
							<select class="form-control select2" data-placeholder="Select The Category" name="CategoryID" style="width: 100%;">
								<?php
									$r = mysql_query("SELECT ID, Name FROM categories ") or die(mysql_error());
									$n = mysql_num_rows($r);
									if($n == 0)
									{
										echo '<option value="0">No Category Added</option>';
									}
									else
									{
										while($Rs = mysql_fetch_assoc($r)) { ?>
										<option value="<?php echo $Rs['ID']; ?>" <?php if($CategoryID==$Rs['ID']) { echo 'Selected=""'; } ?>><?php echo $Rs['Name']; ?></option>
										<?php }
									}
							?>
							</select>
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Whole Sale Price</label>
						<div class="col-md-8">
							<input type="number" class="form-control" value="<?php echo $WholePrice;?>" placeholder="Enter Whole Sale Price" name="WholePrice" id="WholePrice">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Retail Price</label>
						<div class="col-md-8">
							<input type="number" class="form-control" value="<?php echo $RetailPrice;?>" placeholder="Enter Retail Price" name="RetailPrice">
						</div>
					</div>
                    <div class="form-group" id="CurrentStock">
						<label class="col-md-3 control-label" for="example-text-input">Current Stock</label>
						<div class="col-md-8">
							<input type="number" class="form-control" readonly="" value="<?php echo $CurrentStock;?>" placeholder="Enter CurrentStock" name="CurrentStock">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">New Stock</label>
						<div class="col-md-8">
							<input type="number" class="form-control" value="<?php echo $Stock;?>" placeholder="Enter Stock" name="Stock" id="Stock">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Short Description</label>
						<div class="col-md-8">
							<input type="text" class="form-control" value="<?php echo $ShortDescription;?>" placeholder="Enter Short Description" name="ShortDescription">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Description</label>
						<div class="col-md-8">
							<textarea class="form-control" name="Description" id="Description" ><?php echo stripslashes($Description);?></textarea>
						</div>
					</div>
                  </div><!-- /.box-body -->
                </div><!-- /.box-body -->
              </div><!-- /.box-body -->
              <div class="col-md-6">
              <div class="box box-default">
				<div class="box-header with-border">
				  <h3 class="box-title">Supplier Information</h3>
				  <div class="box-tools pull-right">
					<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				  </div>
				</div>
                <div class="box-body">
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input"></label>
						<div class="col-md-8">
							<input type="checkbox" value="1" id="NewOldSupplier" <?php echo ($NewOldSupplier == "1") ? 'checked=""' : '' ;?> name="NewOldSupplier"><label> New Supplier</label>
						</div>
					</div>
                    <div class="form-group" id="SupplierName">
						<label class="col-md-3 control-label" for="example-text-input">Name</label>
						<div class="col-md-8">
							<input type="text" class="form-control" value="<?php echo $SupplierName;?>" placeholder="Enter Supplier Name" name="SupplierName">
						</div>
					</div>
                    <div class="form-group" id="SupplierID">
					<label class="col-md-3 control-label" for="example-text-input">Supplier</label>
						<div class="col-md-8">
							<select class="form-control select2" data-placeholder="Select The Supplier" name="SupplierID" style="width: 100%;">
								<option value="0"></option>
								<?php
									$r = mysql_query("SELECT ID, Name FROM users ") or die(mysql_error());
									$n = mysql_num_rows($r);
									if($n == 0)
									{
										echo '<option value="0">No User Added</option>';
									}
									else
									{
										while($Rs = mysql_fetch_assoc($r)) { ?>
										<option value="<?php echo $Rs['ID']; ?>" <?php if($SupplierID==$Rs['ID']) { echo 'Selected=""'; } ?>><?php echo $Rs['Name']; ?></option>
										<?php }
									}
							?>
							</select>
							<div id="SImage"></div>
						</div>
					</div>
					<div class="form-group" id="SFile">
						<label class="col-md-3 control-label" for="example-text-input">Image</label>
						<div class="col-md-8">
							<input type="file" name="SFile">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">NIC</label>
						<div class="col-md-8">
							<input type="text" class="form-control" value="<?php echo $NIC;?>" placeholder="Enter NIC Number" name="NIC">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Address</label>
						<div class="col-md-8">
							<input type="text" class="form-control" value="<?php echo $Number;?>" placeholder="Enter Address" name="Number">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Address</label>
						<div class="col-md-8">
							<textarea class="form-control" name="Address"><?php echo $Address;?></textarea>
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Email</label>
						<div class="col-md-8">
							<input type="email" class="form-control" value="<?php echo $Email;?>" placeholder="Enter Email" name="Email">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Remarks</label>
						<div class="col-md-8">
							<textarea class="form-control" name="Remarks"><?php echo stripcslashes($Remarks);?></textarea>
						</div>
					</div>
                  </div><!-- /.box-body -->
                </div><!-- /.box-body -->
              </div><!-- /.box-body -->
              <div class="col-md-6">
			  <div class="box box-default">
				<div class="box-header with-border">
				  <h3 class="box-title">Payment Information</h3>
				  <div class="box-tools pull-right">
					<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				  </div>
				</div>
                <div class="box-body">
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Total Amount</label>
						<div class="col-md-8">
							<input type="number" class="form-control" placeholder="Enter the Total Amount" readonly="" name="TotalAmount" value="<?php echo $TotalAmount; ?>" id="TotalAmount">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Discount</label>
						<div class="col-md-8">
							<input type="number" class="form-control" placeholder="Enter the Discount Amount" value="<?php echo $Discount; ?>" name="Discount">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Amount Paying</label>
						<div class="col-md-8">
							<input type="number" class="form-control" placeholder="Enter the initial amount paying" value="<?php echo $Paid; ?>" name="Paid">
						</div>
					</div>
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Note</label>
						<div class="col-md-8">
							<textarea class="form-control" name="Note"><?php echo stripslashes($Note);?></textarea>
						</div>
					</div>
                  </div><!-- /.box-body -->
                </div><!-- /.box-body --> 
              </div><!-- /.box -->
              <?php if(CAPTCHA_VERIFICATION == 1) { ?>
              <div class="col-md-6">
			  <div class="box box-default">
				<div class="box-header with-border">
				  <h3 class="box-title">Human Verification</h3>
				  <div class="box-tools pull-right">
					<button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				  </div>
				</div>
                <div class="box-body">
                    <div class="form-group">
						<label class="col-md-3 control-label" for="example-text-input">Captcha</label>
						<div class="col-md-8">
							<img src="captcha.php" />
							<input type="text" class="form-control" placeholder="Enter the captcha" name="captcha">
						</div>
					</div>
                  </div><!-- /.box-body -->
                </div><!-- /.box-body --> 
              </div><!-- /.box -->
			  <?php } ?>
				</form>
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->

      <!-- Main Footer -->
      <?php include("footer.php"); ?>
      

      <!-- Control Sidebar -->
      <?php include("rightsidebar.php"); ?>
      <!-- /.control-sidebar -->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
      </div><!-- /.content-wrapper -->

    <!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js"></script>
	<!-- Select2 -->
    <script src="plugins/select2/select2.full.min.js"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <!-- CK Editor -->
    <script src="https://cdn.ckeditor.com/4.4.3/standard/ckeditor.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
    <!-- page script -->
<script>
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

 //       CKEDITOR.replace('Description');
        //bootstrap WYSIHTML5 - text editor
//        $(".Description").wysihtml5();
$( "#Stock" ).change(function() {
		var a = $("#Stock").val() * $("#WholePrice").val();
		$("#TotalAmount").val(a);
	});

	$( "#Stock" ).keyup(function() {
		var a = $("#Stock").val() * $("#WholePrice").val();
		$("#TotalAmount").val(a);
	});
	$( "#WholePrice" ).change(function() {
		var a = $("#Stock").val() * $("#WholePrice").val();
		$("#TotalAmount").val(a);
	});
	$( "#WholePrice" ).keyup(function() {
		var a = $("#Stock").val() * $("#WholePrice").val();
		$("#TotalAmount").val(a);
	});


		});

		
	$(document).ready(function(){
if($("#NewOldProduct").prop('checked') == true) <!-- FOR NEW PRODUCT -->
			{
				$("#ProductID").slideUp();
				$("#ProductName").slideDown();
				$("#CurrentStock").slideUp();
				$("#PFile").slideDown();
			}
			else
			{
				$("#ProductName").slideUp();
				$("#ProductID").slideDown();
				$("#CurrentStock").slideDown();
				$("#PFile").slideUp();
			}
		$("#NewOldProduct").change(function () {
			if($("#NewOldProduct").prop('checked') == true) <!-- FOR NEW PRODUCT -->
			{
				$("#ProductID").slideUp();
				$("#ProductName").slideDown();
				$("#CurrentStock").slideUp();
				$("#PFile").slideDown();
			}
			else 									<!-- FOR OLD PRODUCT -->
			{
				$("#ProductName").slideUp();
				$("#ProductID").slideDown();
				$("#CurrentStock").slideDown();
				$("#PFile").slideUp();
			}
		});
		});

	$(document).ready(function(){
		$("[name='ProductID']").change(function () {
			$.ajax({			
					url: 'get_product_details.php?ID='+$("[name='ProductID']").val(),
					dataType: 'json',
					success: function(data, status) {
//						var d =json_decode(data);
						var result = data;

						$(".select2").select2();
						$("[name='BarCode']").val(result["BarCode"]);
						$("[name='OldBarCode']").val(result["BarCode"]);
						$("[name='CategoryID']").val(result["CategoryID"]);
						$("[name='Description']").val(result["Description"]);
						$("[name='ShortDescription']").val(result["ShortDescription"]);
						$("[name='WholePrice']").val(result["WholePrice"]);
						$("[name='RetailPrice']").val(result["RetailPrice"]);
						$("[name='CurrentStock']").val(result["Stock"]);
						$("#PImage").html('<img src="<?php echo DIR_PRODUCT_IMAGES; ?>'+result["Image"]+'" width="100" height="100"><img src="barcode.php?text='+result["BarCode"]+'" width="120" height="80">');
						var a = $("#Stock").val() * $("#WholePrice").val();
						$("#TotalAmount").val(a);
						},
					error: function (xhr, textStatus, errorThrown) {
						alert(xhr.responseText);
					}
			});
		});
		});
		
		
		
		
		<!-- FOR SUPPLIER -->
		
	$(document).ready(function(){
			if($("#NewOldSupplier").prop('checked') == true) <!-- FOR NEW Supplier -->
			{
				$("#SupplierID").slideUp();
				$("#SupplierName").slideDown();
				$("#SFile").slideDown();
			}
			else 									<!-- FOR OLD Supplier -->
			{
				$("#SupplierName").slideUp();
				$("#SupplierID").slideDown();
				$("#SFile").slideUp();
			}
		$("#NewOldSupplier").change(function () {
			if($("#NewOldSupplier").prop('checked') == true) <!-- FOR NEW Supplier -->
			{
				$("#SupplierID").slideUp();
				$("#SupplierName").slideDown();
				$("#SFile").slideDown();
			}
			else 									<!-- FOR OLD Supplier -->
			{
				$("#SupplierName").slideUp();
				$("#SupplierID").slideDown();
				$("#SFile").slideUp();
			}
		});
		});

	$(document).ready(function(){
		$("[name='SupplierID']").change(function () {
			$.ajax({			
					url: 'get_supplier_details.php?ID='+$("[name='SupplierID']").val(),
					success: function(data, status) {
//						var d =json_decode(data);
						var result = [];

						a = data.split('HERESPLITHERE'); 
						while(a[0]) {
							result.push(a.splice(0,1));
						}
//						alert(data);
//						$("[name='SupplierName']").val(result[1]);
						$("[name='NIC']").val(result[2]);
						$("[name='Number']").val(result[3]);
						$("[name='Address']").val(result[4]);
						$("[name='Email']").val(result[5]);
						$("[name='Remarks']").val(result[6]);
						$("#SImage").html('<img src="<?php echo DIR_USER_IMAGES; ?>'+result[1]+'" width="100" height="100">');
						},
					error: function (xhr, textStatus, errorThrown) {
						alert(xhr.responseText);
					}
			});
		});
		});
				
    </script>
</body>
</html>
