<aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">

          <!-- Sidebar user panel (optional) -->
          <div class="user-panel">
            <div class="pull-left image">
              <img src="<?php echo ($_SESSION["Image"] == "" ? 'dist/img/user2-160x160.jpg' : DIR_USER_IMAGES.$_SESSION["Image"]) ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
              <p><?php echo $_SESSION["UserName"]; ?></p>
              <!-- Status -->
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>

         

          <!-- Sidebar Menu -->
          <ul class="sidebar-menu">
            <li class="header">Menu</li>
            <!-- Optionally, you can add icons to the links -->
            <li class="<?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/dashboard.php") ? 'active' : ''); ?>" ><a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a></li>
<?php
if($_SESSION["RoleID"] == 1 || $_SESSION["RoleID"] == 2)
{
	?>
            <li class="treeview <?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/students.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/admins.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/customers.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/suppliers.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/staff.php") ? 'active' : ''); ?>">
              <a href="#"><i class="fa fa-group"></i> <span>User Management</span> <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li class="<?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/admins.php") ? 'active' : ''); ?>"><a href="admins.php"><i class="fa fa-circle-o"></i>Users</a></li>
              </ul>
            </li>
<?php
}
?>

<?php
if($_SESSION["RoleID"] == 1 || $_SESSION["RoleID"] == 2)
{
	?>
            <li class="treeview <?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/categories.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/addevent.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/editevent.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/eventcalendar.php") ? 'active' : ''); ?>">
              <a href="#"><i class="fa fa-cube"></i> <span>Inventory</span> <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
                <li class="<?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/products.php") ? 'active' : ''); ?>"><a href="products.php"><i class="fa fa-circle-o"></i>Cylinder Management</a></li>
                <li class="<?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/categories.php") ? 'active' : ''); ?>"><a href="categories.php"><i class="fa fa-circle-o"></i>Categories</a></li>
                
              </ul>
            </li>
<?php
}
?>
<?php
if($_SESSION["RoleID"] == 1 || $_SESSION["RoleID"] == 2)
{
	?>
            <li class="treeview <?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/students.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/admins.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/customers.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/suppliers.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/staff.php") ? 'active' : ''); ?>">
              <a href="#"><i class="fa fa-group"></i> <span>Shop Management</span> <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
            
              </ul>
            </li>
<?php
}
?>
<?php
if($_SESSION["RoleID"] == 1 || $_SESSION["RoleID"] == 2)
{
	?>
            <li class="treeview <?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/students.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/admins.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/customers.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/suppliers.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/staff.php") ? 'active' : ''); ?>">
              <a href="#"><i class="fa fa-group"></i> <span>Accounts</span> <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
            
              </ul>
            </li>
<?php
}
?>
<?php
if($_SESSION["RoleID"] == 1 || $_SESSION["RoleID"] == 2)
{
	?>
            <li class="treeview <?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/students.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/admins.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/customers.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/suppliers.php") ? 'active' : ''); ?><?php echo (($_SERVER['PHP_SELF'] == dirname($_SERVER['PHP_SELF'])."/staff.php") ? 'active' : ''); ?>">
              <a href="#"><i class="fa fa-group"></i> <span>Reports</span> <i class="fa fa-angle-left pull-right"></i></a>
              <ul class="treeview-menu">
            
              </ul>
            </li>
<?php
}
?>
          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>