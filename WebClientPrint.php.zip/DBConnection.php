<?php
	 //define("DB_HOST", "localhost");
	 //define("DB_NAME", "pos");
	 //define("DB_USERNAME", "root");
	 //define("DB_PASSWORD", "");

	define("DB_HOST", "localhost");
	define("DB_NAME", "et786999_wrdp4");
	define("DB_USERNAME", "et786999_haris");
	define("DB_PASSWORD", "haris12345");
?>