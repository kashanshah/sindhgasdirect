<?php
	 define("DB_HOST", "localhost");
	 define("DB_NAME", "sindhgasdirect");
	 define("DB_USERNAME", "root");
	 define("DB_PASSWORD", "password");

//	define("DB_HOST", "localhost");
//	define("DB_NAME", "et786999_sindhgas");
//	define("DB_USERNAME", "et786999_sindhga");
//	define("DB_PASSWORD", "sindhgas123?");

//	define("DB_HOST", "localhost");
//	define("DB_NAME", "et786999_sindhgasv11");
//	define("DB_USERNAME", "et786999_sgdv1");
//	define("DB_PASSWORD", "sindhgas123?");
