<footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
        <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="http://www.elitetech.ae">EliteTech</a>.</strong> All rights reserved.
        </div>
        <!-- Default to the left -->
          Powered by <a href="http://www.elitetech.ae">EliteTech</a>
      </footer>